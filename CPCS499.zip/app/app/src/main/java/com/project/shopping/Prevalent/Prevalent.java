package com.project.shopping.Prevalent;

import com.project.shopping.Model.Users;

public class Prevalent {
    public static Users currentOnlineUser;

    public static final String UserPhoneKey = "UserPhone";
    public static final String UserPasswordKey = "UserPassword";
}
